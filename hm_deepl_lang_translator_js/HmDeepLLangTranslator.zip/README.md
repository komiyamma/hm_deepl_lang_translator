# HmDeepLLangTranslator

![HmDeepLLangTranslator v1.2.0](https://img.shields.io/badge/HmDeepLLangTranslator-v1.2.0-6479ff.svg)
[![MIT](https://img.shields.io/badge/license-MIT-blue.svg?style=flat)](LICENSE)
![Hidemaru 9.19](https://img.shields.io/badge/Hidemaru-v9.19-6479ff.svg)

「DeepL API Free」というずっと無料の翻訳APIを利用して、英語を日本語に、日本語を英語にする

https://秀丸マクロ.net/?page=nobu_tool_hm_deepl_lang_translator_js
